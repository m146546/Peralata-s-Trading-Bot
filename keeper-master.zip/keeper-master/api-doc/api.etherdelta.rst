EtherDelta API
==============

.. automodule:: api.etherdelta
    :members:
