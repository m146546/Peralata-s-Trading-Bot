Data feeds API
==============

.. automodule:: api.feed
    :members:
